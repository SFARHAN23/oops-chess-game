#include"includes.h"

int main() {
    game qGame;
    qGame.Start(0);
    return 0;
}